import sys, os, time

path_to_index = sys.argv[1]
file = open(os.path.join(path_to_index,'index.txt'),'r')
lines = file.readlines()
file.close()

query = sys.argv[2]
len_query = len(query)
print(lines[len_query].strip())