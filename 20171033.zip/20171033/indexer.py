import sys, os, time

file = open(sys.argv[1],'r')
lines = file.readlines()
file.close()


path_to_index = sys.argv[2]
file = open(os.path.join(path_to_index,'index.txt'),'w')
for i in range(1000000):
	file.write(str(i))
	file.write('\n')

time.sleep(1)
file.close()

file = open(sys.argv[3],'w')
file.write(str(len(lines)))
file.close()