#!/bin/bash

python3 search.py $1 $2