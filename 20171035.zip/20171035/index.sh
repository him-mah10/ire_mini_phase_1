#!/bin/bash

python3 indexer.py $1 $2 $3